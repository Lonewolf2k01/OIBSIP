function display(){
    if((document.getElementById("thetitle").value == "")||(document.getElementById("description").value == "")){
        alert("Please Enter the Text!!!");
     
    }
    else{
     displa();
     document.getElementById("thetitle").value=" ";
     document.getElementById("description").value=" ";

    }
}
        
function displa(){
            document.getElementById("task").innerHTML += `
               <div class = "1">
                    <div id="dele">
                      ${document.getElementById("description").value}
                    
                      <button class = "delete">
                         <pre>  x  </pre>
                      </button>
                    </div>
               </div> 
            `;
    
       var total_Tasks=[]
       var total_Tasks = document.querySelectorAll(".delete");
       for(var i=0; i<total_Tasks.length ; i++){
          total_Tasks[i].onclick = function(){
            this.parentNode.remove();  
             
       }
    }
}